package com.company;

public class SavingsAccount{

    private String name;
    private double balance;

    public void deposit(int x){

        this.balance+=x;
    }

    public SavingsAccount (String name, double balance){

        this.name = name;
        this.balance = balance;
    }

    public double getBalance(){

        return this.balance;
    }

    public void withdraw(double money){


        if(money > 0) {

            if (money > this.getBalance()) {

                System.out.println("Balance is too low to make the withdrawal!");

            }else{

                this.balance-=money;
                System.out.println("Balance after withdrawal: "+this.getBalance());
            }


        }else{

            System.out.println("Invalid argument!");
        }
    }

}