package com.company;

public class Main {

    public static void main(String[] args) {

        SavingsAccount savingsAccount = new SavingsAccount("Account1", 100);

        savingsAccount.deposit(50);
        savingsAccount.withdraw(75);


    }
}
